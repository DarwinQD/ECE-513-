% Darwin Quiroz
% ECE 321
% 09/04/2020
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Homework 2.2.2 Verifying results from table 1.20 of textbook
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% There are 4 potentials calculated in table each with a different position
% The spacing between potentials was evenly split to be about 1/3 of the
% total length.
x_pos = [1/3, 2/3];
y_pos = [1/3, 2/3];
% each side of the pipe is held at a constant potential given as such:
V_l = 80;
V_b = 60;
V_t = 100;
V_r = 20;
% Initializing arrays that will be used to measure the potential. The total
% potential at a certain position is found by the sum of the potentials of
% each individual side. 
Phi_l = zeros(1,4);
Phi_r = zeros(1,4);
Phi_b = zeros(1,4);
Phi_t = zeros(1,4);
% Each potential formula derived for each side is a harmonic series that
% will become more accurate as more terms are added. The number of terms
% calculated is given by N_limit
N_limit = 10;
% an array is going to be then made for the x and y functions that make up
% each potential Phi_r, Phi_l, ... 
n = 1:N_limit;
% an outer for loop is made that will calculated the potential at all 4
% points 
for i = 1:4
    % a case statement is made to determine which point is to be
    % calculated. Referring back to the figure given above table 1.20
    if i == 1
        x = x_pos(1);
        y = y_pos(2);
    elseif i ==2
        x = x_pos(2);
        y = y_pos(2);
    elseif i ==3
        x = x_pos(1);
        y = y_pos(1);
    else
        x = x_pos(2);
        y = y_pos(1);
    end
    % Each potential function was comprised of 3 parts multiplied with one
    % another: the x function, y function, and their appropriate constants
    % X and Y functions for Phi_l
    x_l = sinh(n*pi*(1 - x));
    y_l = sin(n*pi*y);
    % X and Y functions for Phi_b
    x_b = sin(n*pi*x);
    y_b = sinh(n*pi*(1-y));
    % X and Y functions for Phi_t
    x_t = sin(n*pi*x);
    y_t = sinh(n*pi*y);
    % X and Y functions for Phi_r
    x_r = sinh(n*pi*x);
    y_r = sin(n*pi*y);
    % this for loop will compute the potential functions of each side (for
    % a given point which was decided earlier by the case statements)
    for k = 1:N_limit
        % All potential function sums only required the odd integer values
        odd_even = rem(k, 2);
        % the constant used in each function were exactly the same when
        % considering x_0 and y_0 to be unitless (in this case exactly the
        % same. Leaving only the following constant times its potential for
        % the corresponding side
        const = (4)/(n(k)*pi*sinh(n(k)*pi));
        % will only add on to the series if k is an odd integer
        if odd_even == 1        
            % all potentials of each side are computed
            Phi_l(i) = Phi_l(i) + x_l(k)*y_l(k)*const*V_l;
            Phi_b(i) = Phi_b(i) + x_b(k)*y_b(k)*const*V_b;
            Phi_t(i) = Phi_t(i) + x_t(k)*y_t(k)*const*V_t;
            Phi_r(i) = Phi_r(i) + x_r(k)*y_r(k)*const*V_r;
        end
    end
    % the total potential at the point is found by computing the sum of the
    % potentials of each side
    Phi(i) = Phi_l(i) + Phi_b(i) + Phi_t(i) + Phi_r(i);
end
% Once all 4 potentials were found, the total potential is then displayed
% to the user.
Phi
