fdtd is the main script that is used to simulate an EM field with different situations.
all other files were used to annotate differences and used for homework. The function developed was fdtd1d_plot and stored in file named HW8_2_Plot_code
		-- this code is used to create the incident, reflected and transmitted wave from the original given simulation plot and wave generated.