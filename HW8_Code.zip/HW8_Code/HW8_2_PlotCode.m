function fdtd1d_plot(Ey)
figure
E1_i = [Ey(1:250)*2/3;zeros(250,1)];
E1_r = [Ey(1:250)*1/3;zeros(250,1)];
E2_t = [;zeros(250,1);Ey(251:500)];
plot(Ey,'b','LineWidth',2);
hold on
plot(E1_i,'r','LineWidth',2);
hold on
plot(E1_r,'y','LineWidth',2);
hold on
plot(E2_t,'g--','LineWidth',2);

title("Plots of electric field under normal incidence");
xlabel("i_x");
ylabel("Amplitude");
legend("E_total","E_1^+","E_1^-","E_2^+");